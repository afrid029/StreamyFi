import styled from "styled-components";

const Wrapper = styled.div`
.footer{
    background-color: rgb(3, 3, 3);
    height: 10px;
    padding: 5px 10px;
    position: fixed;
    bottom: 0px;
    width: 100vw;

}


`

export default Wrapper;